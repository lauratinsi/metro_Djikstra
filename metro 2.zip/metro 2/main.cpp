#include <iostream>
#include "nodes.h"
#include "vecnodes.h"
#include <list>
#include <fstream>
#include <string>
#include <list>
#include <map>
#include <vector>
#include "station.h"

long _infinite = 10000000000000;
using namespace std;
int main() {

    //1° Construction of the Adjacency matrix


        //Mise en forme des données
            //fonction AllPlan : adresse à rentrer : "chemin_dans_lequel_est_le_projet "metro 2"_telechargé+/RATP_GTFS_METRO_"

    vector<vector<vector<string> > > W = station::AllPlan("/Users/lauratinsi/ClionProjects/metro 2/RATP_GTFS_METRO_");

            //fonction Station : première adresse à rentrer "chemin_dans_lequel_est_le_projet "metro 2"_telechargé+/stops.txt"
            //fonction Station : deuxieme adresse à rentrer "chemin_dans_lequel_est_le_projet "metro 2"_telechargé+/RATP_GTFS_METRO_"

    vector<string> S =station::Station("/Users/lauratinsi/ClionProjects/metro 2/stops.txt" ,"/Users/lauratinsi/ClionProjects/metro 2/RATP_GTFS_METRO_");

        //Préparation de la matrice d'adjacence

    vector<vector<long> > N = station::MatAdj(W,S);




    //2° ENTRER LES DEUX STATIONS ENTRE LESQUELLES LE CHEMIN DOIT ETRE TRACE

    vector<int> B = station::enter("Odéon" ,"Le Peletier", W,S);

        // Lancement du Djikstra

    vector<int> F = vecnodes::Djikstra(N, nodes(B[0],-1,_infinite,1), nodes(B[1],-1,_infinite,1));

        // Traduction en noms de stations "lisibles" de la sortie du Djikstra

    vector<string> A = station::Way(F, W, S);

    //3° Affichage

    //vector<vector<string>> D = station::design(A, W);
    //for(int i(0); i<D.size(); ++i){
    //    cout<< D[2][i] << endl;
    //}



}
